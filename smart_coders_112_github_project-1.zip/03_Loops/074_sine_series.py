"""Smart Coders - Problem 74: sine series."""

import math
x,n=map(float,input().split()); s=0
for k in range(int(n)): s+=(-1)**k*x**(2*k+1)/math.factorial(2*k+1)
print(s)
