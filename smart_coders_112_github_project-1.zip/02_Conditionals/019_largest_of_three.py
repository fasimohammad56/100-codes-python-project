"""Smart Coders - Problem 19: largest of three."""

a,b,c=map(int,input().split()); print("Largest:",max(a,b,c))
