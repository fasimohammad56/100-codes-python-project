"""Smart Coders - Problem 34: quadratic roots."""

import cmath
a,b,c=map(float,input().split()); d=b*b-4*a*c; print((-b+cmath.sqrt(d))/(2*a),(-b-cmath.sqrt(d))/(2*a))
