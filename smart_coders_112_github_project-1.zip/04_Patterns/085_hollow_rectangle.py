"""Smart Coders - Problem 85: hollow rectangle."""

r,c=map(int,input().split())
for i in range(r): print("* "*c if i in (0,r-1) else "* "+"  "*(c-2)+"*" )
