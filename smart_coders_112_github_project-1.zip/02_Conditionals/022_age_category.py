"""Smart Coders - Problem 22: age category."""

age=int(input()); print("Child" if age<13 else "Teenager" if age<20 else "Adult" if age<60 else "Senior")
