"""Smart Coders - Problem 23: time greeting."""

h=int(input()); print("Morning" if h<12 else "Afternoon" if h<17 else "Evening" if h<21 else "Night")
