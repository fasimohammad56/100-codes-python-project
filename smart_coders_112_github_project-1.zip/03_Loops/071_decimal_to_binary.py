"""Smart Coders - Problem 71: decimal to binary."""

n=int(input()); print(bin(n)[2:])
