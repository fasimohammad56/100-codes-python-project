"""Smart Coders - Problem 48: count digits."""

n=abs(int(input())); print("Digits:",len(str(n)))
