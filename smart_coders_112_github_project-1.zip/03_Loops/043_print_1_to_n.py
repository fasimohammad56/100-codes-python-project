"""Smart Coders - Problem 43: print 1 to n."""

n=int(input()); print(*range(1,n+1))
