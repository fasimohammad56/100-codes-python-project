"""Smart Coders - Problem 102: alphabet pyramid."""

n=int(input())
for i in range(1,n+1): print(" "*(n-i),*[chr(65+j) for j in range(i)]+[chr(65+j) for j in range(i-2,-1,-1)])
