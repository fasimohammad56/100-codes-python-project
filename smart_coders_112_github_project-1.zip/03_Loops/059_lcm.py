"""Smart Coders - Problem 59: lcm."""

import math
a,b=map(int,input().split()); print("LCM:",abs(a*b)//math.gcd(a,b))
