"""Smart Coders - Problem 108: right arrow pattern."""

n=int(input())
for i in range(n): print("*"*(i+1) if i<=n//2 else "*"*(n-i))
