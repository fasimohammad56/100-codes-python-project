"""Smart Coders - Problem 80: right aligned triangle."""

n=int(input());
for i in range(1,n+1): print(" "*(n-i)+"*"*i)
