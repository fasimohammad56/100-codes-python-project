"""Smart Coders - Problem 28: triangle type."""

a,b,c=map(int,input().split()); print("Equilateral" if a==b==c else "Isosceles" if a==b or b==c or a==c else "Scalene")
