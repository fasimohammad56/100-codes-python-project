"""Smart Coders - Problem 1: sum difference product quotient remainder."""

a,b=map(float,input("Enter two numbers: ").split())
print("Sum:",a+b); print("Difference:",a-b); print("Product:",a*b); print("Quotient:",a/b); print("Remainder:",a%b)
