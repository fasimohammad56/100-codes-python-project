"""Smart Coders - Problem 96: reverse number triangle."""

n=int(input())
for i in range(n,0,-1): print(*range(i,0,-1))
