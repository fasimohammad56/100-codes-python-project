"""Smart Coders - Problem 62: alternating sum."""

n=int(input()); print(sum(i if i%2 else -i for i in range(1,n+1)))
