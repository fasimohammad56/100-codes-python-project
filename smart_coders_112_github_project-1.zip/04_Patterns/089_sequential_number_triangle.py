"""Smart Coders - Problem 89: sequential number triangle."""

n=int(input()); x=1
for i in range(1,n+1): print(*range(x,x+i)); x+=i
