"""Smart Coders - Problem 75: string palindrome recursion."""

def pal(s): return len(s)<2 or s[0]==s[-1] and pal(s[1:-1])
s=input(); print("Palindrome" if pal(s) else "Not palindrome")
