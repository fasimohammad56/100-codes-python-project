"""Smart Coders - Problem 11: even or odd bitwise."""

n=int(input()); print("Even" if n&1==0 else "Odd")
