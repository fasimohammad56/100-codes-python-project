"""Smart Coders - Problem 50: reverse number."""

n=input(); print("Reverse:",n[::-1])
