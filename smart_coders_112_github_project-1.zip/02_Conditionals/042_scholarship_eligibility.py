"""Smart Coders - Problem 42: scholarship eligibility."""

marks,att,income=map(float,input().split()); print("Eligible" if marks>=80 and att>=75 and income<=500000 else "Not eligible")
