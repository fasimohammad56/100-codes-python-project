"""Smart Coders - Problem 31: days in month."""

m=int(input()); print([31,28,31,30,31,30,31,31,30,31,30,31][m-1] if 1<=m<=12 else "Invalid")
