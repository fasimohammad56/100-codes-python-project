"""Smart Coders - Problem 20: vowel or consonant."""

c=input().lower(); print("Vowel" if c in "aeiou" else "Consonant")
