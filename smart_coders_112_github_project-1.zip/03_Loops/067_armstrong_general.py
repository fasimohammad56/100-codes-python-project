"""Smart Coders - Problem 67: armstrong general."""

n=int(input()); d=len(str(abs(n))); print("Armstrong" if sum(int(x)**d for x in str(abs(n)))==n else "Not Armstrong")
