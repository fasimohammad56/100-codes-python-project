"""Smart Coders - Problem 12: swap using xor."""

a,b=map(int,input().split()); a^=b; b^=a; a^=b; print(a,b)
