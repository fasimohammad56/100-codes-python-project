"""Smart Coders - Problem 41: clock angle."""

h,m=map(int,input().split()); a=abs(30*(h%12)+.5*m-6*m); print("Smaller angle:",min(a,360-a))
