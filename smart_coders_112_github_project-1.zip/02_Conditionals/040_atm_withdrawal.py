"""Smart Coders - Problem 40: atm withdrawal."""

balance,amount=map(float,input().split()); print("Approved" if amount<=balance and balance-amount>=1000 else "Rejected")
