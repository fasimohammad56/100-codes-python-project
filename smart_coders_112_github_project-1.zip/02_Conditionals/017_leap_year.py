"""Smart Coders - Problem 17: leap year."""

y=int(input()); print("Leap year" if y%400==0 or (y%4==0 and y%100!=0) else "Not a leap year")
