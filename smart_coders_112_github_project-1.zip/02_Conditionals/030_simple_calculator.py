"""Smart Coders - Problem 30: simple calculator."""

a,op,b=input().split(); a=float(a); b=float(b)
if op=="+": print(a+b)
elif op=="-": print(a-b)
elif op=="*": print(a*b)
elif op=="/": print(a/b if b else "Cannot divide by zero")
else: print("Invalid operator")
