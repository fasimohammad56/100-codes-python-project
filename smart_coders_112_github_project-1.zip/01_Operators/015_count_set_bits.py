"""Smart Coders - Problem 15: count set bits."""

n=int(input()); count=0
while n: n&=n-1; count+=1
print("Number of set bits:",count)
