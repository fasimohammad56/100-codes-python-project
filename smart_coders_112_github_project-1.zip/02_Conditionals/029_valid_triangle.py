"""Smart Coders - Problem 29: valid triangle."""

a,b,c=map(int,input().split()); print("Valid triangle" if a+b>c and a+c>b and b+c>a else "Invalid triangle")
