"""Smart Coders - Problem 77: increasing then decreasing recursion."""

def show(n):
    if n: show(n-1); print(n,end=" "); print(n,end=" ")
show(int(input()))
