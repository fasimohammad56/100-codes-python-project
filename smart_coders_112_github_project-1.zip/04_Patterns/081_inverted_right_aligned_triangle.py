"""Smart Coders - Problem 81: inverted right aligned triangle."""

n=int(input());
for i in range(n,0,-1): print(" "*(n-i)+"*"*i)
