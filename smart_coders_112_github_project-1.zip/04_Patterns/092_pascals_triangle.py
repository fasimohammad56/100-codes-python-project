"""Smart Coders - Problem 92: pascals triangle."""

import math
n=int(input())
for i in range(n): print(*[math.comb(i,j) for j in range(i+1)])
