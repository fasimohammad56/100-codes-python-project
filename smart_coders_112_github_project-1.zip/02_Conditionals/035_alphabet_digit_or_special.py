"""Smart Coders - Problem 35: alphabet digit or special."""

c=input(); print("Alphabet" if c.isalpha() else "Digit" if c.isdigit() else "Special character")
