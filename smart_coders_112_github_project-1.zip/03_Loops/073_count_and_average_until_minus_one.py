"""Smart Coders - Problem 73: count and average until minus one."""

total=count=0
while True:
    n=float(input())
    if n==-1: break
    total+=n; count+=1
print("Count:",count,"Average:",total/count if count else 0)
