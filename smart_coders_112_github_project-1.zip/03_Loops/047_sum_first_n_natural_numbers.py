"""Smart Coders - Problem 47: sum first n natural numbers."""

n=int(input()); print("Sum:",n*(n+1)//2)
