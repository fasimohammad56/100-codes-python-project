"""Smart Coders - Problem 10: character type."""

c=input(); print("Uppercase" if c.isupper() else "Lowercase" if c.islower() else "Digit" if c.isdigit() else "Special character")
