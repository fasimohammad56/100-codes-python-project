"""Smart Coders - Problem 72: binary to decimal."""

b=input(); print(int(b,2))
