"""Smart Coders - Problem 51: palindrome number."""

n=input(); print("Palindrome" if n==n[::-1] else "Not palindrome")
