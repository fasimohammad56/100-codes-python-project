"""Smart Coders - Problem 76: count vowels recursion."""

def v(s): return 0 if not s else (s[0].lower() in "aeiou")+v(s[1:])
print(v(input()))
