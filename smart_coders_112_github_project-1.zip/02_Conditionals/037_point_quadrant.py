"""Smart Coders - Problem 37: point quadrant."""

x,y=map(int,input().split()); print("Origin" if x==0 and y==0 else "X-axis" if y==0 else "Y-axis" if x==0 else "Quadrant I" if x>0 and y>0 else "Quadrant II" if x<0 else "Quadrant IV")
