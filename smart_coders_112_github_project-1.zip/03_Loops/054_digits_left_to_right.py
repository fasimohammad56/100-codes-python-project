"""Smart Coders - Problem 54: digits left to right."""

for d in input(): print(d)
