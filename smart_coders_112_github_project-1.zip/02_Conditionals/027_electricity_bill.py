"""Smart Coders - Problem 27: electricity bill."""

u=float(input()); bill=2*u if u<=100 else 200+3*(u-100) if u<=200 else 500+5*(u-200); print("Bill:",bill)
