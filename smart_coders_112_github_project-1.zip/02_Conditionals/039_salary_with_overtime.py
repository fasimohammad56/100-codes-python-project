"""Smart Coders - Problem 39: salary with overtime."""

h,r=map(float,input().split()); print("Salary:",40*r+(h-40)*1.5*r if h>40 else h*r)
