"""Smart Coders - Problem 46: odd numbers 1 to n."""

n=int(input()); print(*range(1,n+1,2))
