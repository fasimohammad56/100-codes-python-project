"""Smart Coders - Problem 14: kth bit set."""

n,k=map(int,input().split()); print("Set" if n&(1<<k) else "Not set")
