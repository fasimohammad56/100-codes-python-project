"""Smart Coders - Problem 106: zigzag pattern."""

n=int(input())
for i in range(n): print("*   "*3 if i%2==0 else "  * "*3)
