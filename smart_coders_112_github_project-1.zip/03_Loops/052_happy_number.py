"""Smart Coders - Problem 52: happy number."""

n=int(input()); seen=set()
while n!=1 and n not in seen: seen.add(n); n=sum(int(d)**2 for d in str(n))
print("Happy" if n==1 else "Not happy")
