"""Smart Coders - Problem 103: butterfly pattern."""

n=int(input())
for i in list(range(1,n+1))+list(range(n-1,0,-1)): print("*"*i+" "*(2*(n-i))+"*"*i)
