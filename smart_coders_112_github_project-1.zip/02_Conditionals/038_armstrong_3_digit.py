"""Smart Coders - Problem 38: armstrong 3 digit."""

n=int(input()); print("Armstrong" if sum(int(d)**3 for d in str(n))==n else "Not Armstrong")
