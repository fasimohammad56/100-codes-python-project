"""Smart Coders - Problem 98: alphabet triangle row repeat."""

n=int(input())
for i in range(n): print(*([chr(65+i)]*(i+1)))
