"""Smart Coders - Problem 66: sum even and odd."""

n=int(input()); print("Even sum:",sum(range(2,n+1,2))); print("Odd sum:",sum(range(1,n+1,2)))
