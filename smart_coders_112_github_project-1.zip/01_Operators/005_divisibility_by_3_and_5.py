"""Smart Coders - Problem 5: divisibility by 3 and 5."""

n=int(input("Number: ")); print("Divisible by both" if n%3==0 and n%5==0 else "Divisible by 3" if n%3==0 else "Divisible by 5" if n%5==0 else "Neither")
