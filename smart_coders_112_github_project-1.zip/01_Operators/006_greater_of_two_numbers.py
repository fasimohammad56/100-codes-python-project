"""Smart Coders - Problem 6: greater of two numbers."""

a,b=map(int,input().split()); print("Greater:",max(a,b))
