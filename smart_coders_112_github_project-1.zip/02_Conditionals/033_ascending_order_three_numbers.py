"""Smart Coders - Problem 33: ascending order three numbers."""

a,b,c=map(int,input().split()); a,b=sorted((a,b)); b,c=sorted((b,c)); a,b=sorted((a,b)); print(a,b,c)
