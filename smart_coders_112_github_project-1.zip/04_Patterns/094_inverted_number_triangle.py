"""Smart Coders - Problem 94: inverted number triangle."""

n=int(input())
for i in range(n,0,-1): print(*range(1,i+1))
