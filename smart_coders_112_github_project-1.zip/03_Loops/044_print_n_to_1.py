"""Smart Coders - Problem 44: print n to 1."""

n=int(input()); print(*range(n,0,-1))
