"""Smart Coders - Problem 87: sandglass."""

n=int(input())
for i in list(range(n,0,-1))+list(range(2,n+1)): print("*"*(2*i-1))
