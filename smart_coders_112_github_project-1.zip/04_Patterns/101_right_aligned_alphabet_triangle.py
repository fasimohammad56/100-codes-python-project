"""Smart Coders - Problem 101: right aligned alphabet triangle."""

n=int(input())
for i in range(1,n+1): print(" "*(n-i),*[chr(65+j) for j in range(i)])
