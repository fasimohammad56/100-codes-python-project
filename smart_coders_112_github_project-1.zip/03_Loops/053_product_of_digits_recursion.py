"""Smart Coders - Problem 53: product of digits recursion."""

def product(n):
    return n if n<10 else n%10*product(n//10)
n=int(input()); print("Product:",product(abs(n)))
