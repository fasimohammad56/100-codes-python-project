"""Smart Coders - Problem 32: positive then even odd."""

n=int(input()); print("Even" if n%2==0 else "Odd") if n>0 else print("Negative" if n<0 else "Zero")
