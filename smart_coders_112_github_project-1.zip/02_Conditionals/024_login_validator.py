"""Smart Coders - Problem 24: login validator."""

u=input(); p=input(); print("Valid login" if u=="admin" and p=="1234" else "Invalid login")
