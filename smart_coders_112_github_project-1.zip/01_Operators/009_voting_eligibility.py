"""Smart Coders - Problem 9: voting eligibility."""

age=int(input()); print("Eligible to vote" if age>=18 else "Not eligible to vote")
