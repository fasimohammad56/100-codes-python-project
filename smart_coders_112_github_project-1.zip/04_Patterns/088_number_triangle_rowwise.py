"""Smart Coders - Problem 88: number triangle rowwise."""

n=int(input())
for i in range(1,n+1): print(" ".join([str(i)]*i))
