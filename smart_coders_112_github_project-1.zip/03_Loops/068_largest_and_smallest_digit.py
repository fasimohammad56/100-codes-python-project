"""Smart Coders - Problem 68: largest and smallest digit."""

s=input(); print("Largest:",max(s),"Smallest:",min(s))
