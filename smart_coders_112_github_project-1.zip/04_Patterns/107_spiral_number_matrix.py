"""Smart Coders - Problem 107: spiral number matrix."""

n=int(input()); a=[[0]*n for _ in range(n)]; v=1; t=b=l=r=0; b=n-1; r=n-1
while t<=b:
 for j in range(l,r+1): a[t][j]=v; v+=1
 t+=1
 for i in range(t,b+1): a[i][r]=v; v+=1
 r-=1
 if t<=b:
  for j in range(r,l-1,-1): a[b][j]=v; v+=1
  b-=1
 if l<=r:
  for i in range(b,t-1,-1): a[i][l]=v; v+=1
  l+=1
for row in a: print(*row)
