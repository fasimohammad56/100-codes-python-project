"""Smart Coders - Problem 25: grade from marks."""

m=int(input()); print("A" if m>=90 else "B" if m>=80 else "C" if m>=70 else "D" if m>=60 else "F")
