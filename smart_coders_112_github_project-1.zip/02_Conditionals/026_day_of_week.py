"""Smart Coders - Problem 26: day of week."""

d=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]; n=int(input()); print(d[n-1] if 1<=n<=7 else "Invalid")
