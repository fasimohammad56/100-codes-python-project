"""Smart Coders - Problem 97: binary number triangle."""

n=int(input())
for i in range(1,n+1): print(*[j%2 for j in range(i)])
