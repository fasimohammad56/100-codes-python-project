"""Smart Coders - Problem 61: harmonic series sum."""

n=int(input()); print(sum(1/i for i in range(1,n+1)))
