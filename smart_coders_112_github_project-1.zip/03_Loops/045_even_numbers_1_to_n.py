"""Smart Coders - Problem 45: even numbers 1 to n."""

n=int(input()); print(*range(2,n+1,2))
