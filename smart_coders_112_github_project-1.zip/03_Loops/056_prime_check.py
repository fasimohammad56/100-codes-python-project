"""Smart Coders - Problem 56: prime check."""

n=int(input()); print("Prime" if n>1 and all(n%i for i in range(2,int(n**.5)+1)) else "Not prime")
