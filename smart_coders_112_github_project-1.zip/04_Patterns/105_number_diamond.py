"""Smart Coders - Problem 105: number diamond."""

n=int(input())
for i in list(range(1,n+1))+list(range(n-1,0,-1)): print(" "*(n-i),*[j for j in list(range(1,i+1))+list(range(i-1,0,-1))])
