"""Smart Coders - Problem 91: binary alternating triangle."""

n=int(input())
for i in range(1,n+1): print(*[j%2 for j in range(i)])
