"""Smart Coders - Problem 79: inverted star triangle."""

n=int(input());
for i in range(n,0,-1): print("*"*i)
