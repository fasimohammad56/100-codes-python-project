"""Smart Coders - Problem 21: ticket pricing."""

age=int(input()); print("Ticket price:",100 if age<13 else 150 if age<60 else 80)
