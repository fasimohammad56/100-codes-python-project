"""Smart Coders - Problem 36: profit loss or no profit."""

cp,sp=map(float,input().split()); print("Profit" if sp>cp else "Loss" if sp<cp else "No profit no loss")
