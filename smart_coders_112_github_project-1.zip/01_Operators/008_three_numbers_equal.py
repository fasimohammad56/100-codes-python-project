"""Smart Coders - Problem 8: three numbers equal."""

a,b,c=map(int,input().split()); print("All are equal" if a==b and b==c else "Not all are equal")
