"""Smart Coders - Problem 63: power without pow."""

x,n=map(int,input().split()); r=1
for _ in range(n): r*=x
print(r)
