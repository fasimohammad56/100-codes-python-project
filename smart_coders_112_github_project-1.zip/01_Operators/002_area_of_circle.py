"""Smart Coders - Problem 2: area of circle."""

r=float(input("Enter radius: ")); print("Area:",3.14159*r*r)
