"""Smart Coders - Problem 58: gcd hcf."""

import math
a,b=map(int,input().split()); print("GCD:",math.gcd(a,b))
