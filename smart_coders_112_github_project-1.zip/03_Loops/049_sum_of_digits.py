"""Smart Coders - Problem 49: sum of digits."""

n=abs(int(input())); print("Sum:",sum(map(int,str(n))))
