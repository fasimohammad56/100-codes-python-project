"""Smart Coders - Problem 111: heart shape pattern."""

n=int(input())
for i in range(n//2): print(" *"*2+" "*n+" *"*2)
for i in range(n//2,n): print(" "*(n-i)+"*"*(2*i-n+1))
