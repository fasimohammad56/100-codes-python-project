"""Smart Coders - Problem 104: hollow diamond inside rectangle."""

n=int(input())
for i in range(2*n-1):
 d=min(i,2*n-2-i); print("* "*d+"*"*(2*n-1-2*d)+" *"*d)
