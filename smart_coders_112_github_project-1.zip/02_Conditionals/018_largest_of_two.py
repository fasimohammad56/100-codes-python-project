"""Smart Coders - Problem 18: largest of two."""

a,b=map(int,input().split()); print("Largest:",max(a,b))
