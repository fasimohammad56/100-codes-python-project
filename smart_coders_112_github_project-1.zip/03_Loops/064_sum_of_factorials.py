"""Smart Coders - Problem 64: sum of factorials."""

n=int(input()); f=s=0
for i in range(1,n+1): f=f*i if f else 1; s+=f
print(s)
