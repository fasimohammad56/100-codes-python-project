"""Smart Coders - Problem 16: even or odd."""

n=int(input()); print("Even" if n%2==0 else "Odd")
