"""Smart Coders - Problem 4: celsius fahrenheit conversion."""

c=float(input("Celsius: ")); print("Fahrenheit:",c*9/5+32)
f=float(input("Fahrenheit: ")); print("Celsius:",(f-32)*5/9)
